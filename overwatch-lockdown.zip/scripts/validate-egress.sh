#!/usr/bin/env bash
# Verifies the sandbox can reach Anthropic and nothing else.
# Run from the HOST while the sandbox is running. Usage: validate-egress.sh [sandbox-name]
set -u
SBX="${1:-claude-overwatch}"
pass=0; fail=0
ok(){ echo "PASS  $1"; pass=$((pass+1)); }
bad(){ echo "FAIL  $1"; fail=$((fail+1)); }
code(){ sbx exec "$SBX" sh -c "curl -s -o /dev/null -w '%{http_code}' -m 5 https://$1" 2>/dev/null; }
blocked(){ [ "$1" = "403" ] || [ "$1" = "000" ] || [ -z "$1" ]; }

# Preflight: abort (never pass) if we can't reach the sandbox
sbx exec "$SBX" sh -c 'command -v curl >/dev/null' 2>/dev/null || { echo "ABORT: cannot exec into '$SBX' (stopped?) or curl missing"; exit 2; }

echo "== Allowed: Anthropic =="
for h in api.anthropic.com platform.claude.com; do
  c=$(code "$h")
  blocked "$c" && bad "$h unreachable ($c)" || ok "$h reachable ($c)"
done

echo "== Blocked: publishing, packages, everything else =="
for h in github.com api.github.com gitlab.com registry.npmjs.org pypi.org example.org \
         claude.ai mcp-proxy.anthropic.com http-intake.logs.us5.datadoghq.com; do
  c=$(code "$h")
  blocked "$c" && ok "$h blocked ($c)" || bad "$h reachable ($c)"
done

echo; echo "Result: $pass passed, $fail failed"; [ "$fail" -eq 0 ]
