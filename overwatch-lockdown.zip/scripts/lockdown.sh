#!/usr/bin/env bash
# Locks sandbox network egress to Anthropic only. Run on the HOST, once.
# Applies to every local sandbox, not just Overwatch.
#   api.anthropic.com    inference
#   platform.claude.com  sign-in token refresh
set -euo pipefail

sbx policy set-default deny-all
sbx policy allow network "api.anthropic.com,platform.claude.com"

echo
echo "Current rules:"
sbx policy ls
